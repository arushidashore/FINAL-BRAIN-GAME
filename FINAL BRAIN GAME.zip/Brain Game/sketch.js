var player_still, player_run
var player_still_left, player_run_left
var player_jump, player_shoot, player_punch, player_beginning
var player_jump_left, player_shoot_left, player_punch_left
var neuron_image, neuron2_image, spark_image
var background_image
var player, background_img
var ground, ground_img
var bullet, bullet_img, enemyGroup, bulletGroup
var load = 0;
var play = 1;
var end = 2;
var gameState = load; 
var title, title_img, start_button, start_button_img
var restart_button, restart_button_img, gameover, gameover_img


function preload(){
  player_still = loadAnimation("../images/player_still.png");
  player_run = loadAnimation("../images/player_run1.png","../images/player_run2.png","../images/player_run3.png");
  player_still_left = loadImage("../images/player_still_left.png");
  player_run_left = loadAnimation("../images/player_run1_left.png","../images/player_run2_left.png","../images/player_run3_left.png");
  player_jump = loadImage("../images/player_jump.png");
  player_shoot = loadImage("../images/player_shoot.png");
  player_punch = loadImage("../images/player_punch.png");
  player_jump_left = loadImage("../images/player_jump_left.png");
  player_shoot_left = loadImage("../images/player_shoot_left.png");
  player_punch_left = loadImage("../images/player_punch_left.png");
  player_beginning = loadImage("../images/player_beginning.png");
  neuron_image = loadImage("../images/neuron_image.png");
  neuron2_image = loadImage("../images/neuron_image_two.png");
  spark_image = loadImage("../images/spark_image.png");
  background_image = loadImage("../images/background_image.png");
  ground_img = loadImage("../images/ground.png");
  bullet_img = loadImage("../images/bullet.png");
  title_img = loadImage("../images/title.png");
  start_button_img = loadImage("../images/startButton.png");
  restart_button_img = loadImage("../images/restart_button_img.png");
  gameover_button_img = loadImage("../images/gameover_img.png");

}
function setup() {
  createCanvas(800,300);
  background_img = createSprite(displayWidth/2+500, displayHeight/2-100, 1200, displayHeight);
  background_img.addImage(background_image);
  background_img.scale = 2.5;
  background_img.velocityX=-4;
  background_img.x = background_img.width /2;
  background_img.visible = false
  player = createSprite(300,240,15,15);
  player.addAnimation("still_player",player_still);
  player.addAnimation("player_motion",player_run);
  player.addAnimation("jumping",player_jump);
  player.addAnimation("shoot",player_shoot);
  player.visible = false 
  player.scale = 1.5
  ground = createSprite(400,290,800,30);
  ground.visible = false 
  enemyGroup = new Group();
  bulletGroup = new Group();
  start_button = createSprite(400, 250, 100, 100);
  start_button.addImage(start_button_img);
  start_button.scale = 0.4;
  start_button.visible=false;
  title = createSprite(400, 150, 100, 100);
  title.addImage(title_img);
  title.scale = 0.25
  title.visible=false 
  restart_button = createSprite(400,230,100, 100);
  restart_button.addImage(restart_button_img);
  restart_button.scale=0.2;
  gameover = createSprite(400,130,100,100);
  gameover.addImage(gameover_button_img);
  gameover.scale=0.4;
  restart_button.visible=false
  gameover.visible=false 
}

function draw() {
  background(0); 

  if (gameState===load){
    
    textSize(60);
    fill(68, 212, 135);
    stroke(240, 242, 241);
    text("Brain Game!", 235, 80);
    start_button.visible=true;
    title.visible=true; 
    if (mousePressedOver(start_button)){
      gameState=play; 
    }
  }
  
  
    if(gameState===play){
      console.log("gameState working");
      player.visible=true
      start_button.visible=false
      ground.visible=true 
      title.visible=false 
      background_img.visible=true 
    if (background_img.x<410){
      background_img.x = displayWidth/2; 
    }


    player.changeAnimation("player_motion",player_run);

    enemies();

    if (keyWentDown("SPACE")){
      player.changeAnimation("jumping",player_jump);
      player.y=player.y-100;
    }
    if (keyWentUp("SPACE")){
      player.changeAnimation("still_player",player_still);
      player.y=player.y+100;
    }


    if (keyDown("UP_ARROW")){
      player.changeAnimation("shoot",player_shoot);
      bullets();
     
    }

    if (enemyGroup.isTouching(bulletGroup)){
      enemyGroup.destroyEach();
      bulletGroup.destroyEach()
    }

    if (enemyGroup.isTouching(player)){
      gameState=end;
    }
    
}
else if(gameState===end){
  gameOver(); 
  player.visible=false
  ground.visible=false
  background_img.visible=false 
  if (mousePressedOver(restart_button)){
    reset(); 
  }
}
drawSprites();
}

function enemies(){
  var rand = Math.round(random(1,3))
  if (frameCount%50===0){
    enemy = createSprite(400,random(180,275),10,10);
    switch(rand){
      case 1: enemy.addImage(neuron_image);
      enemy.velocityX = -5
      enemy.scale = 0.25
      break;
      case 2: enemy.addImage(neuron2_image);
      enemy.velocityX = -3
      enemy.scale = 0.05
      break;
      case 3: enemy.addImage(spark_image);
      enemy.velocityX = -7
      enemy.scale = 0.25
    }
    enemyGroup.add(enemy)
  }
}

function bullets(){

  bullet = createSprite(player.x,240,15,15);
  bullet.velocityX=5;
  bullet.addImage(bullet_img);
  bullet.scale = 0.01;
  
  bulletGroup.add(bullet)
 
}

function gameOver(){
  background(240, 240, 230); 
  restart_button.visible=true
  gameover.visible=true  
  enemyGroup.destroyEach(); 
}

function reset(){
  gameState=load; 
  restart_button.visible=false
  gameover.visible=false 
}